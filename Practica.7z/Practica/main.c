   #include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>

int main()
{

   int edad ;
    float altura = 1.87;
    char sexo = 'f';
    //edad = 18;
printf("Ingrese edad: ");
    scanf("%d", &edad);
    printf("Ingrese altura: ");
    scanf("%f", &altura);
    printf("Ingrese sexo: ");

    sexo = tolower(getche());


    printf("La edad ingresada es: %d\n\nLa altura es: %f\nY el sexo es: %c",edad , altura, sexo);


    return 0;


}


